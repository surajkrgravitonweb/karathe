import React, { useEffect, useState } from "react";
import moment from "moment"; // Don't forget to import moment

// import "./About.css";
import { tns } from "tiny-slider/src/tiny-slider";
import "@fortawesome/fontawesome-free/css/all.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faArrowLeft, faArrowRight } from "@fortawesome/free-solid-svg-icons";
import { toast } from "react-toastify";

import { useNavigate, useLocation } from "react-router-dom";
import axios from 'axios';

const HomeLoan = () => {

  const [formData, setFormData] = useState({
    userID: localStorage.getItem("userID"),
    employment_type: "null",
    personalloanform_businessloanform_id: "",
  });
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    if (location.state) {
      setFormData({ userID: localStorage.getItem("userID"), employment_type: location.state.employment_type, personalloanform_businessloanform_id: location.state.param });
    }
  }, [location.state]);



  useEffect(() => {
    // Initialize the Tiny Slider
    const slider = tns({
      container: ".sliderFirst",
      items: 1,
      controlsContainer: "#sliderFirstControls",
      prevButton: ".prev",
      nextButton: ".next",
    });
    document.querySelector(".tns-nav").style.display = "none";
    // Clean up on component unmount
    return () => {
      slider.destroy();
    };
  }, []);
  const toastConfig = {
    position: "top-right",
    autoClose: 5000,
    hideProgressBar: true,
    closeOnClick: true,
    pauseOnHover: true,
    draggable: true,
    progress: undefined,
  };


  const [textDisabld, setTextDisabld] = useState(false);


  const [selectedLanguage, setSelectedLanguage] = useState("");

  const handleLanguageChange = (event) => {
    setSelectedLanguage(event.target.value);
  };

  let newformData = new FormData();



  const [formData2, setFormData2] = useState({
    ownership_proof: null,
    mutation_copy: null,
    land_revenue: null,
    lpc: null,
    thirteen_year_chaindeed: null,
    propety_map: null,
  })

  const [errors, setErrors] = useState({});

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
    setErrors({ ...errors, [name]: null });


  };


  useEffect(() => {
    if (formData.employment_type === "salaried" && formData.personalloanform_businessloanform_id === "") {
      navigate("/personalloan", { state: { param: formData.employment_type } }) // Clear errors for the changed field
    } else if (formData.employment_type === "selfemployed" && formData.personalloanform_businessloanform_id === "") {
      navigate("/businessloan", { state: { param: formData.employment_type } }) // Clear errors for the changed field
    }
  }, [formData.employment_type])


  console.log(formData2);

  const handleFileChange = (e, fieldName) => {
    const file = e.target.files[0];

    // Ensure the selected file is a PDF file
    if (file && file.type === "application/pdf") {
      // Update the specific field in formData
      setFormData2({
        ...formData2,
        [fieldName]: file,
      });
    } else {
      // Handle the case where the selected file is not a PDF
      alert("Please select a PDF file.");
      e.target.value = null; // Clear the input field
    }
  };

  // console.log(formData2);

  const validateForm = () => {
    const newErrors = {};

    // Add your validation logic here


    if (!formData.employment_type) {
      newErrors.employment_type = "Employment is Requried";
    }
    if (!formData2.ownership_proof) {
      newErrors.ownership_proof = "Files is Requried";
    }
    if (!formData2.mutation_copy) {
      newErrors.mutation_copy = "mutation_copy Files is Requried";
    }
    if (!formData2.land_revenue) {
      newErrors.land_revenue = "Income Files is Requried";
    }
    if (!formData2.lpc) {
      newErrors.lpc = "Regproof is Requried";
    }
    if (!formData2.propety_map) {
      newErrors.propety_map = "Last Two Year AS is Requried";
    }

    if (!formData2.thirteen_year_chaindeed) {
      newErrors.thirteen_year_chaindeed = "Last two year  is Requried";
    }


    setErrors(newErrors);

    // Return true if there are no errors
    return Object.keys(newErrors).length === 0;
  };


  const handleClick = async (e) => {
    e.preventDefault();
    console.log('formData------>', formData);
    // console.log(selectedLanguage);
    // console.log(dividendArr6)
    // console.log(dividendArr5)
    // console.log(dividendArr4)
    // console.log(dividendArr3)
    // console.log(dividendArr2)
    // console.log(dividendArr1)
    // console.log(dividendArr)

    const object = { formData }
    console.log(object);


    // Append all files to the formData
    Object.keys(formData2).forEach((fileType) => {
      const file = formData2[fileType];
      console.log(fileType);
      if (file) {
        newformData.append(fileType, file);
      }
    });

    try {

      let headersList = {
        "Accept": "*/*",
        "Content-Type": "application/json"
      }

      let bodyContent = JSON.stringify(object);

      let reqOptions = {
        url: "http://localhost:8000/api/v1/homeLoanForm",
        method: "POST",
        headers: headersList,
        data: bodyContent,
      }

      let response = await axios.request(reqOptions);
      console.log(response.data);

      if (response) {
        // Handle success
        console.log(response.data.id);
        const response2 = await axios.post(`http://localhost:8000/api/v1/homeloanformUploadfiles/${response.data.id}`, newformData, {
          headers: {
            'Content-Type': 'multipart/form-data',
          },
        });

        if (response2) {
          alert(response2.data.message);
          navigate('/');
        } else {
          console.error('Error sending data to the backend');
        }

      } else {
        // Handle error
        console.error('Error sending data to the backend');
      }
    } catch (error) {
      console.error('Error:', error);
    }

    if (validateForm()) {
      console.log(formData);
      // If form validation fails, do not submit
      return;
    }
  };
  console.log(formData);

  return (
    <>
      <main>
        <section>
          <div className="position-relative">
            <ul className="controls" id="sliderFirstControls">
              <li className="prev">
                <FontAwesomeIcon icon={faArrowLeft} />
              </li>

              <li className="next">
                <FontAwesomeIcon icon={faArrowRight} />
              </li>
            </ul>
            <div className="sliderFirst">
              <div className="item">
                <div className="py-22 businessloan-banner-one">
                  <div className="container">
                    <div className="row">
                      <div className="col-xl-8 col-lg-9 col-md-12 col-sm-12 col-12">
                        <div>
                          {/* slider-captions */}
                          <h1 className="display-2 text-white fw-bold">
                            Hassle free Small Home loan up to &#x20B9; ₹20,00,000.00
                          </h1>
                          <p className="d-none d-xl-block d-lg-block d-sm-block text-white mb-4">
                            Home Loan From JoyoMoney Platform At An Attractive Rate Of Interest. Apply Now!
                          </p>

                          {/* <span className="badge bg-success ms-md-3">
                            Rate of interest: Up to 16% - 32%
                          </span> */}
                        </div>
                        {/* /.slider-captions */}
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="item">
                <div className="py-22 businessloan-banner-two ">
                  <div className="container">
                    <div className="row">
                      <div className="col-xl-9 col-md-12 col-sm-12 col-12">
                        <div>
                          <h1 className="display-2 text-white fw-bold">
                            The key to business growth with JoyoMoney Theme
                          </h1>
                          <p className=" d-none d-xl-block d-lg-block d-sm-block text-white mb-4">
                            The flexibility in loan you need for the need you want!
                            <strong>02269620449</strong>
                          </p>

                          {/* <span className="badge bg-success ms-md-3">
                            Rate of interest: Up to 16% - 32%
                          </span> */}
                        </div>
                        {/* /.slider-captions */}
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="item">
                <div className="py-22 businessloan-banner-three">
                  <div className="container">
                    <div className="row">
                      <div className="col-xl-8 col-lg-9 col-md-12 col-sm-12 col-12">
                        <div>
                          {/* slider-captions */}
                          <h1 className="display-2 text-white fw-bold">
                            Looking to set up or expand your business?
                          </h1>
                          <p className=" d-none d-xl-block d-lg-block d-sm-block text-white mb-4">

                            Online, Ontime, Onsite Loan for your business growth.
                          </p>

                          {/* <span className="badge bg-success ms-md-3">
                            Rate of interest: Up to 16% - 32%
                          </span> */}
                        </div>
                        {/* /.slider-captions */}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="pt-3 pb-6 ">
          <div className="container">
            <div className="row">
              <div className="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <div className="bg-white p-5 rounded-top-md">
                  <div className="row align-items-center">
                    <div className="col-md-6 col-xl-8 col-sm-12 col-12">
                      <h1 className="mb-0">Home Loan</h1>
                    </div>
                    <div className="col-xl-4 col-md-6 col-12">
                      <div className="text-md-end mt-3 mt-md-0">
                        <a href="#!" className="btn btn-primary">
                          Get A Call Back
                        </a>
                        <a href="/contact" className="btn btn-secondary">
                          How To Apply
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
                <div>
                  <ul className="nav nav-fill nav-pills-gray-fill">
                    <li className="nav-item">
                      <a href="#section-about" className="page-scroll nav-link">
                        About Loan
                      </a>
                    </li>
                    <li className="nav-item">
                      <a
                        href="#section-typeloan"
                        className="page-scroll nav-link"
                      >
                        Types of loan
                      </a>
                    </li>
                    <li className="nav-item">
                      <a
                        href="#section-feature"
                        className="page-scroll nav-link"
                      >
                        Features &amp; Benefits
                      </a>
                    </li>
                    <li className="nav-item">
                      <a
                        href="#section-eleigiblity"
                        className="page-scroll nav-link"
                      >
                        Eligibility
                      </a>
                    </li>

                    <li className="nav-item">
                      <a href="/" className="page-scroll nav-link">
                        Apply now
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* content start */}
        <section>
          <div className="container">
            <div className="row">
              <div className="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <div className="mt-n6 bg-white mb-10 rounded-3 shadow-sm position-relative">
                  <div
                    className="section-scroll p-lg-10 p-5"
                    id="section-about"
                  >
                    <h2>About Home Loan</h2>
                    <p className="lead">
                      A home loan in India is a financial product provided by banks and financial
                      institutions to individuals looking to purchase or construct a residential
                      property. These loans are a popular means for individuals to fulfill their dream of owning a home, as they allow
                      borrowers to acquire funds to buy a house and repay the amount over an extended period.
                    </p>
                    <div className="row">
                      <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                        <p>
                          Vestibulum accumsan, diam vitae consectetur sodales
                          sapien felis vestibulum purus,ac porttitor elit dolor
                          venenatis Cras condimacilicelerisque orci nisi sit
                          amet neque.{" "}
                        </p>
                      </div>
                      <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                        <p>
                          Pellentesque mollis, diam a viverra luctus, nisl dui
                          vehicula erat, id congue ante justo nec ante. Nullam
                          vehicula tellus sit amet dolor tristique, faucibus
                          rhoncus velit elementum.
                        </p>
                      </div>
                    </div>
                    <hr />
                    <p>
                      Phasellus tellus nunc, sollicitudin quist amet it simple
                      nequeuisque lacus mi tesimly diummy cintenbt mpus nec
                      purus vitae tempor placerat leo.{" "}
                    </p>


                    <h2> Here are some key points about home loans in India:</h2>
                    <h3>1.	Eligibility Criteria:</h3>
                    <ul className="text-decoration: none;">
                      <li>	Age: Typically, individuals between 18 and 70 years old are eligible for home loans.</li>
                      <li>	Income: Lenders assess the borrower's income, employment stability, and repayment capacity.</li>
                      <li>	Credit Score: A good credit score enhances the chances of loan approval.</li>
                    </ul>
                    <h3>2.	Loan Amount:</h3>
                    <ul className="text-decoration: none;">
                      <li>		The loan amount depends on factors like the applicant's income, the property's cost, and the loan-to-value (LTV) ratio.</li>
                      <li>	LTV ratio is the percentage of the property's value that the lender is willing to finance. The borrower needs to fund the remaining amount through their savings</li>

                    </ul>
                    <h3>3.	Interest Rates:</h3>
                    <ul className="text-decoration: none;">
                      <li>	Home loan interest rates can be fixed or floating.</li>
                      <li>	Fixed rates remain constant throughout the loan tenure, while floating rates change based on market conditions.</li>
                    </ul>
                    <h3>4.	Loan Tenure:</h3>
                    <ul className="text-decoration: none;">
                      <li>	Home loans have a maximum tenure of up to 30 years, allowing borrowers to repay the amount in equated monthly installments (EMIs).</li>
                    </ul>

                    <h3>5.	Types of Home Loans:</h3>
                    <ul className="text-decoration: none;">
                      <li>	Purchase Loan: For buying a new or resale property.</li>
                      <li>	Construction Loan: For constructing a new house.</li>
                      <li>	Home Improvement Loan: For renovating or improving an existing property.</li>
                      <li>	Balance Transfer: Transferring an existing home loan to another lender for better terms.</li>
                    </ul>

                    <h3>6.	Tax Benefits:</h3>
                    <ul className="text-decoration: none;">
                      <li>	Borrowers can avail tax benefits on the principal and interest repaid on home loans under sections 80C and 24(b) of the Income Tax Act, respectively</li>
                    </ul>

                    <h3>7.	Documents Required:</h3>
                    <ul className="text-decoration: none;">
                      <li>KYC documents</li>
                      <li>Income proof</li>
                      <li>Property documents</li>
                      <li>	Bank statements</li>
                      <li>Employment details</li>

                    </ul>
                    <h3>8.EMI Calculation:</h3>
                    <ul className="text-decoration: none;">
                      <li>	Equated Monthly Installments (EMIs) consist of both principal and interest components.</li>
                      <li>	The EMI amount remains constant, but the interest and principal proportions change over time.</li>
                    </ul>

                    <h3>9.	Prepayment and Foreclosure:</h3>
                    <ul className="text-decoration: none;">
                      <li>	Borrowers can prepay a part or the entire outstanding loan amount before the tenure ends.</li>
                      <li>Some lenders may charge prepayment penalties, while others allow it without any charges</li>
                    </ul>
                    <h3>10.	Insurance:</h3>
                    <ul className="text-decoration: none;">
                      <li>		Lenders may require borrowers to take home loan insurance to cover the outstanding amount in case of the borrower's demise.</li>
                    </ul>


                  </div>
                  <div className="section-scroll" id="section-typeloan">
                    <div className="bg-light p-lg-10 p-5">
                      <div className="row">
                        <div className="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                          <div className="mb-5">
                            <h2>Get financing for whatever you need now</h2>
                            <p>
                              Achieve all your goals and aspirations; with the
                              right kind of help, exactly when you need it.
                            </p>
                          </div>
                        </div>
                      </div>
                      <div className="row">
                        <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                          <div className=" mb-5">
                            <h4>New Home Loan</h4>
                            <p className="mb-0">
                              New Home Loan at basic interest rates from
                              JoyoMoney Company. You can apply online and
                              check your eligibility and easy EMI. Fast Approval
                              for your new home loan.
                            </p>
                          </div>
                        </div>
                        <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                          <div className=" mb-5">
                            <h4>Home Conversion</h4>
                            <p className="mb-0">
                              A home conversion loan is a scheme for those who
                              have already taken a housing loan. This loan
                              follow some rules and regulations.It is a part of
                              loan.
                            </p>
                          </div>
                        </div>
                        <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                          <div className=" mb-5 mb-lg-0">
                            <h4>Land Purchase</h4>
                            <p className="mb-0">
                              JoyoMoneyoffers home loan for land purchase to
                              make your dream home. You can compare home loan
                              rates with our compare loan table. Apply online
                              for Home Loan.
                            </p>
                          </div>
                        </div>
                        <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                          <div className=" mb-5 mb-lg-0">
                            <h4>Home Renovation</h4>
                            <p className="mb-0">
                              Get instant approval for renovation your home.
                              Borrow introduce home improvement loan. It is with
                              basic rate and flexible EMI repayment.For more
                              detail you can check our loan products.
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="bg-primary py-8 text-center">
                    <div className="row">
                      <div className="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <h1 className="text-white mb-4">
                          Get financing for whatever you need now
                        </h1>
                        <a href="/contact" className="btn btn-white">
                          Enquire Now
                        </a>
                      </div>
                    </div>
                  </div>
                  <div className="section-scroll" id="section-feature">
                    <div className="p-lg-10 p-5">
                      <div className="row">
                        <div className="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                          <div className="mb-6">
                            <h2>Features of Home Loan</h2>
                            <p>
                              {" "}
                              All loans are not created equal, personal loan has
                              become a great option for people to use.
                            </p>
                          </div>
                        </div>
                      </div>
                      <div className="row">
                        <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                          <div className="feature-icon mb-4">
                            <div className="mb-3">
                              <svg
                                xmlns="http://www.w3.org/2000/svg"
                                width={32}
                                height={32}
                                fill="currentColor"
                                className="bi bi-laptop text-primary"
                                viewBox="0 0 16 16"
                              >
                                <path d="M13.5 3a.5.5 0 0 1 .5.5V11H2V3.5a.5.5 0 0 1 .5-.5h11zm-11-1A1.5 1.5 0 0 0 1 3.5V12h14V3.5A1.5 1.5 0 0 0 13.5 2h-11zM0 12.5h16a1.5 1.5 0 0 1-1.5 1.5h-13A1.5 1.5 0 0 1 0 12.5z" />
                              </svg>
                            </div>
                            <h4>Salaried &amp; Self Employed</h4>
                            <p>
                              Home loans are available for both salaried individuals and self-employed individuals in India. Salaried individuals typically need to provide proof of stable income, employment details, and salary slips
                              It's essential for applicants to understand the documentation and eligibility criteria specific to their employment status when applying for a home loan.
                            </p>
                          </div>
                        </div>
                        <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                          <div className="feature-icon mb-4">
                            <div className="mb-3">
                              <svg
                                xmlns="http://www.w3.org/2000/svg"
                                width={32}
                                height={32}
                                fill="currentColor"
                                className="bi bi-lightbulb text-primary"
                                viewBox="0 0 16 16"
                              >
                                <path d="M2 6a6 6 0 1 1 10.174 4.31c-.203.196-.359.4-.453.619l-.762 1.769A.5.5 0 0 1 10.5 13a.5.5 0 0 1 0 1 .5.5 0 0 1 0 1l-.224.447a1 1 0 0 1-.894.553H6.618a1 1 0 0 1-.894-.553L5.5 15a.5.5 0 0 1 0-1 .5.5 0 0 1 0-1 .5.5 0 0 1-.46-.302l-.761-1.77a1.964 1.964 0 0 0-.453-.618A5.984 5.984 0 0 1 2 6zm6-5a5 5 0 0 0-3.479 8.592c.263.254.514.564.676.941L5.83 12h4.342l.632-1.467c.162-.377.413-.687.676-.941A5 5 0 0 0 8 1z" />
                              </svg>
                            </div>
                            <h4>Loan For Agriculturists</h4>
                            <p>
                              Home loans tailored for agriculturists in India are designed to accommodate the unique financial circumstances of individuals involved in agriculture. These specialized loans take into consideration the variability of agricultural income and typically require proof of land ownership, crop details, and income generated from farming activities. Collateral, often in the form of agricultural land, may be necessary to secure the loan
                            </p>
                          </div>
                        </div>
                        <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                          <div className="feature-icon mb-4">
                            <div className="mb-3">
                              <svg
                                xmlns="http://www.w3.org/2000/svg"
                                width={32}
                                height={32}
                                fill="currentColor"
                                className="bi bi-bullseye text-primary"
                                viewBox="0 0 16 16"
                              >
                                <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />
                                <path d="M8 13A5 5 0 1 1 8 3a5 5 0 0 1 0 10zm0 1A6 6 0 1 0 8 2a6 6 0 0 0 0 12z" />
                                <path d="M8 11a3 3 0 1 1 0-6 3 3 0 0 1 0 6zm0 1a4 4 0 1 0 0-8 4 4 0 0 0 0 8z" />
                                <path d="M9.5 8a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
                              </svg>
                            </div>
                            <h4>Home Loans For NRIs</h4>
                            <p>
                              Home loans for Non-Resident Indians (NRIs) in India are financial products specifically designed to facilitate property purchase for individuals living abroad. NRIs can apply for home loans to buy residential properties in India for self-occupation or as an investment. Lenders typically consider factors such as the applicant's income, employment stability, and creditworthiness
                            </p>
                          </div>
                        </div>
                        <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                          <div className="feature-icon mb-4">
                            <div className="mb-3">
                              <svg
                                xmlns="http://www.w3.org/2000/svg"
                                width={32}
                                height={32}
                                fill="currentColor"
                                className="bi bi-currency-dollar text-primary"
                                viewBox="0 0 16 16"
                              >
                                <path d="M4 10.781c.148 1.667 1.513 2.85 3.591 3.003V15h1.043v-1.216c2.27-.179 3.678-1.438 3.678-3.3 0-1.59-.947-2.51-2.956-3.028l-.722-.187V3.467c1.122.11 1.879.714 2.07 1.616h1.47c-.166-1.6-1.54-2.748-3.54-2.875V1H7.591v1.233c-1.939.23-3.27 1.472-3.27 3.156 0 1.454.966 2.483 2.661 2.917l.61.162v4.031c-1.149-.17-1.94-.8-2.131-1.718H4zm3.391-3.836c-1.043-.263-1.6-.825-1.6-1.616 0-.944.704-1.641 1.8-1.828v3.495l-.2-.05zm1.591 1.872c1.287.323 1.852.859 1.852 1.769 0 1.097-.826 1.828-2.2 1.939V8.73l.348.086z" />
                              </svg>
                            </div>
                            <h4>No Morgage</h4>
                            <p>
                              A Balance Transfer (BT) Top-Up in the context of a home loan refers to an additional loan amount that a borrower can opt for when transferring their existing home loan from one lender to another. This facility allows borrowers to consolidate their outstanding home loan balance with an additional amount required for various purposes such as home renovations, debt consolidation, or any other financial requirements.
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="section-scroll" id="section-eleigiblity">
                    <div className=" bg-light p-lg-10 p-5">
                      <div className="row">
                        <div className="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                          <div className="mb-6">
                            <h2>Home Loan - Eligibility</h2>
                            <p>
                              {" "}
                              Any salaried, self-employed or professional Public
                              and Privat companies, Government sector employees
                              including Public Sector is eligible for a personal
                              loan.{" "}
                            </p>
                          </div>
                        </div>
                      </div>
                      <div className="row">
                        <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                          <div className=" mb-4">
                            <h4>Age</h4>
                            <p>
                              Maximum age of applicant at loan maturity: 60
                              years
                            </p>
                          </div>
                        </div>
                        <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                          <div className=" mb-4">
                            <h4>Income</h4>
                            <p>Minimum Net Monthly Income: Rs 15,000</p>
                          </div>
                        </div>
                        <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                          <div className=" mb-4">
                            <h4>Credit Rating</h4>
                            <p>
                              Applicant should have the bank specified credit
                              score.{" "}
                            </p>
                          </div>
                        </div>
                      </div>
                      <div className="row">
                        <div className="offset-xl-3 col-xl-6 offset-lg-3 col-lg-6 offset-md-3 col-md-6 col-sm-12 col-12"></div>
                      </div>
                    </div>
                  </div>

                  <section className="" id="section-apply">
                    <div className="container">
                      <div className="my-2">
                        <div className="offset-xl-2 col-xl-8 offset-lg-2 col-lg-8 col-md-12 col-sm-12 col-12">
                          <div className="mb-4 text-center">
                            {/* section title start*/}
                            <h1 className="mb-0">Loan Application Form </h1>
                            <p>
                              Now apply for a Home Loan online, All you need to
                              do is provide your details below application form.
                            </p>
                          </div>
                        </div>
                        <form>
                          {/* Text input*/}
                          <div className="row">
                            {/* 
                                                          // raido button */}
                            <div className="py-2 d-flex">
                              <span className="mx-4 d-flex">
                                Are you Salaried or Self Employed?
                                <span className="mx-2 d-flex">
                                  <label htmlFor="html">Yes</label>
                                  <input
                                    type="radio"
                                    id="employment_type1"
                                    name="employment_type"
                                    className="m-2"
                                    value="salaried"
                                    checked={formData.employment_type === "salaried"}
                                    onChange={handleInputChange}
                                  />
                                </span>
                                <span className="mx-2 d-flex">
                                  <label htmlFor="css">No</label>
                                  <input
                                    type="radio"
                                    id="employment_type2"
                                    name="employment_type"
                                    className="m-2"
                                    value="selfemployed"
                                    checked={formData.employment_type === "selfemployed"}
                                    onChange={handleInputChange}
                                  />
                                </span>
                                <br />
                              </span>
                            </div>




                            <h3>Property Details</h3>

                            <div className="col-xl-4 col-lg-2 col-md-12 col-sm-12 col-12">
                              <div className="mb-3">
                                <h6 className="text-center">
                                  Ownership Proof/ Saledeed
                                </h6>
                                <label
                                  className="sr-only form-label mb-0"
                                  htmlFor="text"
                                ></label>

                                <input
                                  id="ownership_proof"
                                  name="ownership_proof"
                                  type="file"
                                  onChange={(e) =>
                                    handleFileChange(
                                      e,
                                      "ownership_proof"
                                    )
                                  }
                                  className="form-control"
                                />
                                {errors.ownership_proof && (
                                  <div className="text-danger">
                                    {errors.ownership_proof}
                                  </div>
                                )}
                                {formData2.ownership_proof && (
                                  <p>
                                    Selected File:{" "}
                                    {formData2.ownership_proof.name}
                                  </p>
                                )}
                              </div>
                            </div>
                            <div className="col-xl-4 col-lg-2 col-md-12 col-sm-12 col-12">
                              <div className="mb-3">
                                <h6 className="text-center">
                                  13 year chaindeed
                                </h6>
                                <label
                                  className="sr-only form-label mb-0"
                                  htmlFor="text"
                                ></label>
                                <input
                                  id="thirteen_year_chaindeed "
                                  name="thirteen_year_chaindeed "
                                  type="file"
                                  onChange={(e) =>
                                    handleFileChange(e, "thirteen_year_chaindeed")
                                  }
                                  placeholder="Last Two Year ."
                                  className="form-control"
                                />
                                {errors.thirteen_year_chaindeed && (
                                  <div className="text-danger">
                                    {errors.thirteen_year_chaindeed}
                                  </div>
                                )}
                                {formData2.thirteen_year_chaindeed && (
                                  <p>
                                    Selected File:{" "}
                                    {formData2.thirteen_year_chaindeed.name}
                                  </p>
                                )}
                              </div>
                            </div>
                            <div className="col-xl-4 col-lg-2 col-md-12 col-sm-12 col-12">
                              <div className="mb-3">
                                <h6 className="text-center">
                                  Land revenue details
                                </h6>
                                <label
                                  className="sr-only form-label mb-0"
                                  htmlFor="text"
                                ></label>
                                <input
                                  id="land_revenue"
                                  name="land_revenue"
                                  type="file"
                                  onChange={(e) =>
                                    handleFileChange(e, "land_revenue")
                                  }

                                  className="form-control"
                                />
                                {errors.land_revenue && (
                                  <div className="text-danger">
                                    {errors.land_revenue}
                                  </div>
                                )}
                                {formData2.land_revenue && (
                                  <p>
                                    Selected File:{" "}
                                    {formData2.land_revenue.name}
                                  </p>
                                )}
                              </div>
                            </div>

                            <div className="col-xl-4 col-lg-2 col-md-12 col-sm-12 col-12">
                              <div className="mb-3">
                                <h6 className="text-center">
                                  Mutation copy/ Dakhilkhariz
                                </h6>
                                <label
                                  className="sr-only form-label mb-0"
                                  htmlFor="text"
                                ></label>
                                <input
                                  id="mutation_copy"
                                  name="mutation_copy"
                                  type="file"
                                  onChange={(e) =>
                                    handleFileChange(e, "mutation_copy")
                                  }

                                  className="form-control"
                                />
                                {errors.mutation_copy && (
                                  <div className="text-danger">
                                    {errors.mutation_copy}
                                  </div>
                                )}
                                {formData2.mutation_copy && (
                                  <p>
                                    Selected File: {formData2.mutation_copy.name}
                                  </p>
                                )}
                              </div>
                            </div>

                            <div className="col-xl-4 col-lg-2 col-md-12 col-sm-12 col-12">
                              <div className="mb-3">
                                <h6 className="text-center">
                                  Property Map
                                </h6>
                                <label
                                  className="sr-only form-label mb-0"
                                  htmlFor="text"
                                ></label>
                                <input
                                  id="propety_map "
                                  name="propety_map "
                                  type="file"
                                  onChange={(e) =>
                                    handleFileChange(e, "propety_map")
                                  }

                                  className="form-control"
                                />
                                {errors.propety_map && (
                                  <div className="text-danger">
                                    {errors.propety_map}
                                  </div>
                                )}
                                {formData2.propety_map && (
                                  <p>
                                    Selected File:{" "}
                                    {formData2.propety_map.name}
                                  </p>
                                )}
                              </div>
                            </div>
                            <div className="col-xl-4 col-lg-2 col-md-12 col-sm-12 col-12">
                              <div className="mb-3">
                                <h6 className="text-center">
                                  LPC (Land Possession Certificate)
                                </h6>
                                <label
                                  className="sr-only form-label mb-0"
                                  htmlFor="text"
                                ></label>
                                <input
                                  id="lpc"
                                  name="lpc"
                                  type="file"
                                  onChange={(e) =>
                                    handleFileChange(
                                      e,
                                      "lpc"
                                    )
                                  }
                                  placeholder="Last Three Month Salary Slip."
                                  className="form-control"
                                />
                                {errors.lpc && (
                                  <div className="text-danger">
                                    {errors.lpc}
                                  </div>
                                )}
                                {formData2.lpc && (
                                  <p>
                                    Selected File:{" "}
                                    {formData2.lpc.name}
                                  </p>
                                )}
                              </div>
                            </div>

                            {/* Button */}

                            <div className=" col-lg-12 col-md-12 col-sm-12 col-12">
                              <button
                                onClick={handleClick}
                                type="submit"
                                className="btn btn-primary mb-4"
                              >
                                Submit
                              </button>
                            </div>

                          </div>


                        </form>
                      </div>
                    </div>
                  </section>
                </div>
              </div>
            </div>
          </div>
        </section>
        {/* /.content end */}
      </main>
    </>
  );
};
export default HomeLoan;
