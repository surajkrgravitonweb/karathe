import React from 'react'
import Sidebar from './Sidebar'

const BankForm = () => {
  return (
  <>
  <Sidebar>
      <section className='py-lg-16 py-10'>

        Bank form 
      </section>
  
      </Sidebar>
  </>
  )
}

export default BankForm