import React from 'react'

function File() {
  return (
    <div>This is File</div>
  )
}

export default File