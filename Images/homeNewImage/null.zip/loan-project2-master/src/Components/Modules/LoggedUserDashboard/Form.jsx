import React from 'react'

function Form() {
  return (
    <div>This is Form</div>
  )
}

export default Form