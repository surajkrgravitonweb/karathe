import React from 'react'

const Agent = () => {
  return (
    <>
    <div className='py-lg-20 py-16 '>

    This is Agent  Pannel
   </div>
   </>
  )
}

export default Agent