const config = {
  BASE_API_URL: process.env.BASE_URL,
};

export default config;
